package org.cap.controller;

import java.util.List;

import org.cap.model.HotelDetails;
import org.cap.service.IBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookingController {
	@Autowired
	private IBookingService bookingService;
	@RequestMapping("/")
	public String  showAllHotels(ModelMap map) {
		List<HotelDetails> hotel = bookingService.getHotel();
		map.put("hotels", hotel);
		return "HotelDetails";
	}
	@RequestMapping("/booking/{name}")
	public String showBookingPage(@PathVariable("name") String name, ModelMap map) {
		HotelDetails hotels = bookingService.getHotelByName(name);
		map.put("hotel", hotels);
		return "HotelBooking";
	}
	@RequestMapping("/booking/bookingDone/{name}")
	public ModelAndView showBookingPage(@PathVariable("name")String name) {
		return new ModelAndView("BookingConfirmation", "name", name);
		
	}

}
