package org.cap.service;

import java.util.List;

import org.cap.model.HotelDetails;

public interface IBookingService {
	
	public HotelDetails getHotelByName(String name);
	public List<HotelDetails> getHotel();
}
