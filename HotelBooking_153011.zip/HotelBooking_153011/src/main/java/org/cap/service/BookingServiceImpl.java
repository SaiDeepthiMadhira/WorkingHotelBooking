package org.cap.service;

import java.util.List;

import org.cap.dao.IBookingDAO;
import org.cap.model.HotelDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("bookingService")
public class BookingServiceImpl implements IBookingService{
	@Autowired
	private IBookingDAO bookingDao;
	@Override
	public List<HotelDetails> getHotel(){
		
		return bookingDao.getHotel();
	}
	@Override
	public HotelDetails getHotelByName(String name) {
		// TODO Auto-generated method stub
		return bookingDao.getHotelByName(name);
	}	
}
