package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.cap.model.HotelDetails;
import org.springframework.stereotype.Repository;
@Transactional
@Repository("bookingDao")
public class BookingDAOImpl implements IBookingDAO{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<HotelDetails> getHotel() {
		List<HotelDetails> hotels = em.createQuery("from HotelDetails").getResultList();
		
		return hotels;
	}

	@Override
	public HotelDetails getHotelByName(String name) {
		Query query = em.createQuery("from HotelDetails where name = :hname");
		query.setParameter("hname", name);
		List<HotelDetails> hotels = query.getResultList();
		return hotels.get(0);
	}

}
