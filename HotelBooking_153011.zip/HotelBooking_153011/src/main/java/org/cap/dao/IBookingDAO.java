package org.cap.dao;

import java.util.List;

import org.cap.model.HotelDetails;

public interface IBookingDAO {
	public List<HotelDetails> getHotel();
	public HotelDetails getHotelByName(String name);
}
